# 1.7 Разработать систему пользователей и ролей
**role** - файл для создания ролей

Ссылки:  
https://postgrespro.ru/docs/postgrespro/10/role-membership
