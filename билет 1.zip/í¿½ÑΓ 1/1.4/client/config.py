host = "127.0.0.1"
user = "postgres"
password = "1758Elephant"
db_name = "bilet_1"
post = 5432